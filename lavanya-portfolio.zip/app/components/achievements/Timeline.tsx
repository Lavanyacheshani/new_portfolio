"use client"

import { motion } from "framer-motion"
import { useState } from "react"

const timelineEvents = [
  {
    year: 2022,
    title: "Started journey in AI & Web Development",
    description: "Began exploring the world of artificial intelligence and web development.",
  },
  {
    year: 2023,
    title: "Led multiple IEEE projects & workshops",
    description: "Took on leadership roles in IEEE, organizing various projects and workshops.",
  },
  {
    year: 2024,
    title: "Best Pitch Award | TECH-TRIATHLON Finalist",
    description: "Won the Best Pitch Award at ICE 2024 and reached the finals of TECH-TRIATHLON 2024.",
  },
]

export default function Timeline() {
  const [hoveredEvent, setHoveredEvent] = useState(null)

  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl font-bold mb-12 text-center text-glow"
        >
          Journey Through Time
        </motion.h2>
        <div className="relative">
          <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-electric-blue"></div>
          {timelineEvents.map((event, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              className={`relative mb-8 ${index % 2 === 0 ? "text-right pr-8" : "text-left pl-8"}`}
              onMouseEnter={() => setHoveredEvent(index)}
              onMouseLeave={() => setHoveredEvent(null)}
            >
              <div
                className={`absolute top-0 ${
                  index % 2 === 0 ? "right-0 mr-4" : "left-0 ml-4"
                } w-4 h-4 rounded-full bg-gold-500`}
              ></div>
              <div className="bg-gray-700 p-4 rounded-lg shadow-lg">
                <h3 className="text-xl font-bold text-gold-500">{event.year}</h3>
                <h4 className="text-lg font-semibold mb-2">{event.title}</h4>
                <p className={`text-sm ${hoveredEvent === index ? "block" : "hidden"}`}>{event.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

