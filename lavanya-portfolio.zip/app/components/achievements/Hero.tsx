"use client"

import { motion } from "framer-motion"
import { Canvas } from "@react-three/fiber"
import { useEffect, useState } from "react"
import { LaurelWreath } from "./LaurelWreath"
import { Button } from "@/components/ui/button"

export default function Hero() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {mounted && (
        <Canvas className="absolute inset-0">
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} />
          <LaurelWreath />
        </Canvas>
      )}
      <div className="relative z-10 text-center">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-6xl font-bold mb-6 text-glow"
        >
          Pushing Boundaries, Achieving Excellence
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-xl mb-8 max-w-2xl mx-auto"
        >
          A journey of dedication, innovation, and learning. Here are the milestones that define my expertise and
          passion for AI, software engineering, and leadership.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex justify-center space-x-4"
        >
          <Button variant="default" className="bg-gold-500 hover:bg-gold-600 text-gray-900">
            View Achievements
          </Button>
          <Button variant="outline" className="border-electric-blue text-electric-blue hover:bg-electric-blue/10">
            View Certifications
          </Button>
        </motion.div>
      </div>
    </section>
  )
}

