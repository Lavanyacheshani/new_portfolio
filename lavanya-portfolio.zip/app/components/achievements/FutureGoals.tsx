"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import { useChat } from "ai/react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function FutureGoals() {
  const [chatVisible, setChatVisible] = useState(false)
  const { messages, input, handleInputChange, handleSubmit } = useChat()

  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl font-bold mb-12 text-center text-glow"
        >
          The Journey Continues... 🚀
        </motion.h2>
        <div className="max-w-3xl mx-auto text-center">
          <p className="text-xl mb-8">
            As I continue to push the boundaries of AI and software engineering, here are some of my future goals and
            aspirations:
          </p>
          <ul className="text-left mb-8 space-y-4">
            <li>🧠 Contribute to cutting-edge AI research in natural language processing</li>
            <li>🌐 Develop innovative solutions for global challenges using AI and web technologies</li>
            <li>📚 Pursue advanced studies in AI and machine learning</li>
            <li>🤝 Mentor and inspire the next generation of tech innovators</li>
          </ul>
          <Button
            onClick={() => setChatVisible(!chatVisible)}
            className="bg-electric-blue hover:bg-electric-blue/80 text-white"
          >
            {chatVisible ? "Hide AI Chatbot" : "Ask About My Future Projects"}
          </Button>
        </div>
        {chatVisible && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-2xl mx-auto mt-8">
            <Card className="bg-gray-800">
              <CardHeader>
                <CardTitle>AI Assistant</CardTitle>
                <CardDescription>Ask me about Lavanya's future projects and goals</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4 h-60 overflow-y-auto">
                  {messages.map((message, index) => (
                    <div key={index} className={`mb-2 ${message.role === "user" ? "text-blue-400" : "text-green-400"}`}>
                      <strong>{message.role === "user" ? "You: " : "AI: "}</strong>
                      {message.content}
                    </div>
                  ))}
                </div>
                <form onSubmit={handleSubmit} className="flex space-x-2">
                  <Input
                    value={input}
                    onChange={handleInputChange}
                    placeholder="Ask about future projects..."
                    className="flex-grow"
                  />
                  <Button type="submit">Send</Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </section>
  )
}

