"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"

const certifications = [
  {
    title: "Certified AI Practitioner",
    issuer: "OpenAI & DeepLearning.AI",
    category: "Artificial Intelligence",
    description: "Advanced certification in AI and machine learning techniques.",
    link: "#",
  },
  {
    title: "Google UX Design Professional Certificate",
    issuer: "Google",
    category: "Web Development",
    description: "Comprehensive UX design certification covering the entire design process.",
    link: "#",
  },
  {
    title: "Meta Front-End Developer Certification",
    issuer: "Meta",
    category: "Web Development",
    description: "Advanced front-end development certification covering React and modern web technologies.",
    link: "#",
  },
  {
    title: "IEEE Leadership Development Certificate",
    issuer: "IEEE",
    category: "Leadership & Volunteering",
    description: "Leadership skills development program for technology professionals.",
    link: "#",
  },
  {
    title: "AWS Cloud Practitioner Certification",
    issuer: "Amazon Web Services",
    category: "Project Management",
    description: "Foundational understanding of AWS Cloud services and their applications.",
    link: "#",
  },
]

const categories = [
  "All",
  "Artificial Intelligence",
  "Web Development",
  "Project Management",
  "Leadership & Volunteering",
]

export default function Certifications() {
  const [filter, setFilter] = useState("All")
  const [search, setSearch] = useState("")

  const filteredCertifications = certifications.filter(
    (cert) => (filter === "All" || cert.category === filter) && cert.title.toLowerCase().includes(search.toLowerCase()),
  )

  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl font-bold mb-12 text-center text-glow"
        >
          Certifications
        </motion.h2>
        <div className="flex justify-center mb-8 space-x-4 flex-wrap">
          {categories.map((category) => (
            <Badge
              key={category}
              variant={filter === category ? "default" : "secondary"}
              className="cursor-pointer"
              onClick={() => setFilter(category)}
            >
              {category}
            </Badge>
          ))}
        </div>
        <div className="mb-8 max-w-md mx-auto">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              type="text"
              placeholder="Search certifications..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCertifications.map((cert, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Dialog>
                <DialogTrigger asChild>
                  <Card className="bg-gray-800 hover:bg-gray-700 transition-colors duration-300 cursor-pointer">
                    <CardHeader>
                      <CardTitle className="text-xl font-bold text-gold-500">{cert.title}</CardTitle>
                      <CardDescription>{cert.issuer}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Badge>{cert.category}</Badge>
                    </CardContent>
                  </Card>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{cert.title}</DialogTitle>
                    <DialogDescription>{cert.issuer}</DialogDescription>
                  </DialogHeader>
                  <p>{cert.description}</p>
                  <a
                    href={cert.link}
                    className="text-electric-blue hover:underline"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    View Certificate
                  </a>
                </DialogContent>
              </Dialog>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

