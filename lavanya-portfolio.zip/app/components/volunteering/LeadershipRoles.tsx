"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import Image from "next/image"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const leadershipRoles = [
  {
    organization: "Google Developer Group Sri Lanka",
    logo: "/logos/gdg.png",
    position: "Volunteer",
    year: "2024/25",
    description: "Contributed to organizing tech events and workshops for the developer community.",
    details:
      "Assisted in planning and executing developer meetups, hackathons, and tech talks. Helped in promoting Google technologies and best practices among local developers.",
    achievements: ["Organized 5+ successful tech events", "Mentored 20+ aspiring developers"],
    image: "/images/gdg-event.jpg",
  },
  {
    organization: "IEEE CS SYP Micro-Mentoring",
    logo: "/logos/ieee-cs.png",
    position: "Regional Liaison & Coordinator (Region 10)",
    year: "2024/25",
    description: "Coordinated mentoring programs for young professionals in the IEEE Computer Society.",
    details:
      "Facilitated mentoring sessions between experienced professionals and young IEEE members. Organized virtual events to promote knowledge sharing and career development.",
    achievements: ["Connected 50+ mentors with mentees", "Organized 3 region-wide virtual events"],
    image: "/images/ieee-cs-event.jpg",
  },
  {
    organization: "IEEE SLSAC",
    logo: "/logos/ieee-slsac.png",
    position: "Financial Management Coordinator",
    year: "2024/25",
    description: "Managed financial aspects of IEEE Student Activities Committee in Sri Lanka.",
    details:
      "Oversaw budget planning and allocation for various student activities. Ensured proper financial reporting and compliance with IEEE guidelines.",
    achievements: ["Managed a budget of $10,000+", "Implemented a new financial tracking system"],
    image: "/images/ieee-slsac-event.jpg",
  },
  {
    organization: "SLTC IEEE Student Branch",
    logo: "/logos/sltc-ieee.png",
    position: "Treasurer",
    year: "2024/25",
    description: "Handled financial responsibilities for the IEEE Student Branch at SLTC.",
    details:
      "Managed branch finances, prepared financial reports, and ensured proper allocation of funds for various IEEE activities and events.",
    achievements: ["Increased branch funds by 30%", "Successfully organized 4 major events within budget"],
    image: "/images/sltc-ieee-event.jpg",
  },
  {
    organization: "SLTC IEEE WIE Subcommittee",
    logo: "/logos/ieee-wie.png",
    position: "Financial Deputy Head",
    year: "2023/24",
    description: "Assisted in financial management of Women in Engineering activities at SLTC.",
    details:
      "Supported the Financial Head in budget planning, expense tracking, and financial reporting for WIE events and initiatives.",
    achievements: ["Co-managed 5+ successful WIE events", "Implemented a digital expense tracking system"],
    image: "/images/ieee-wie-event.jpg",
  },
  {
    organization: "SLTC AIESEC",
    logo: "/logos/aiesec.png",
    position: "Business Development Member",
    year: "2023/24",
    description: "Contributed to business development initiatives for AIESEC.",
    details:
      "Assisted in identifying and pursuing partnership opportunities. Helped in organizing events to promote AIESEC's programs and increase student participation.",
    achievements: ["Secured 3 new partnerships", "Increased student sign-ups by 25%"],
    image: "/images/aiesec-event.jpg",
  },
]

export default function LeadershipRoles() {
  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl font-bold mb-12 text-center text-glow"
        >
          Leadership Roles
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {leadershipRoles.map((role, index) => (
            <RoleCard key={index} role={role} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}

function RoleCard({ role, index }) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Dialog>
        <DialogTrigger asChild>
          <Card
            className="bg-gray-700 hover:bg-gray-600 transition-all duration-300 cursor-pointer"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            <CardHeader>
              <div className="flex items-center justify-between mb-2">
                <Image
                  src={role.logo || "/placeholder.svg"}
                  alt={role.organization}
                  width={50}
                  height={50}
                  className="rounded-full"
                />
                <span className="text-sm text-gray-400">{role.year}</span>
              </div>
              <CardTitle className="text-xl font-bold text-electric-blue">{role.position}</CardTitle>
              <CardDescription>{role.organization}</CardDescription>
            </CardHeader>
            <CardContent>
              <p className={`transition-all duration-300 ${isHovered ? "text-white" : "text-gray-400"}`}>
                {role.description}
              </p>
              <Button className="mt-4 bg-electric-blue hover:bg-electric-blue/80 text-white">View More</Button>
            </CardContent>
          </Card>
        </DialogTrigger>
        <DialogContent className="bg-gray-800 text-white">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-electric-blue">{role.position}</DialogTitle>
            <DialogDescription className="text-gray-400">
              {role.organization} - {role.year}
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            <Image
              src={role.image || "/placeholder.svg"}
              alt={role.organization}
              width={600}
              height={400}
              className="rounded-lg mb-4"
            />
            <p className="mb-4">{role.details}</p>
            <h4 className="font-bold mb-2">Key Achievements:</h4>
            <ul className="list-disc list-inside">
              {role.achievements.map((achievement, index) => (
                <li key={index}>{achievement}</li>
              ))}
            </ul>
          </div>
        </DialogContent>
      </Dialog>
    </motion.div>
  )
}

