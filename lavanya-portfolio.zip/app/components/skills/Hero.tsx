"use client"

import { motion } from "framer-motion"
import { Radar } from "react-chartjs-2"
import { Chart as ChartJS, RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend } from "chart.js"

ChartJS.register(RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend)

const skillData = {
  labels: ["AI", "Web Dev", "UI/UX", "Mobile Dev", "Data Science", "Cloud"],
  datasets: [
    {
      label: "Skill Level",
      data: [90, 85, 80, 75, 70, 65],
      backgroundColor: "rgba(74, 0, 224, 0.2)",
      borderColor: "rgba(142, 45, 226, 1)",
      borderWidth: 2,
    },
  ],
}

const options = {
  scales: {
    r: {
      angleLines: {
        display: false,
      },
      suggestedMin: 0,
      suggestedMax: 100,
      pointLabels: {
        font: {
          size: 14,
        },
        color: "rgba(255, 255, 255, 0.8)",
      },
    },
  },
  plugins: {
    legend: {
      display: false,
    },
  },
}

export default function Hero() {
  return (
    <section className="py-20 bg-gradient-to-br from-gray-900 to-gray-800">
      <div className="container mx-auto px-4">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-5xl font-bold mb-6 text-center text-glow"
        >
          My Skills & Experience – A Journey of Innovation & Growth
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-xl text-center mb-12 text-gray-300"
        >
          A software engineer passionate about AI, web development, and UI/UX design. Here's what I bring to the table!
        </motion.p>
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="max-w-2xl mx-auto"
        >
          <Radar data={skillData} options={options} />
        </motion.div>
      </div>
    </section>
  )
}

