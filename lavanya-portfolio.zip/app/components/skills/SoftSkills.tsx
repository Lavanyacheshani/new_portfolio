"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import { useChat } from "ai/react"

const softSkills = [
  { name: "Communication", icon: "💬" },
  { name: "Team Collaboration", icon: "🤝" },
  { name: "Problem-Solving", icon: "🛠" },
  { name: "Adaptability", icon: "🔄" },
  { name: "Time Management", icon: "⏳" },
  { name: "Leadership", icon: "🎯" },
  { name: "Attention to Detail", icon: "👀" },
  { name: "Continuous Learning", icon: "📚" },
]

export default function SoftSkills() {
  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-3xl md:text-4xl font-bold mb-12 text-center text-glow"
        >
          Beyond Code: My Core Strengths
        </motion.h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {softSkills.map((skill, index) => (
            <SkillHexagon key={index} name={skill.name} icon={skill.icon} />
          ))}
        </div>
      </div>
    </section>
  )
}

function SkillHexagon({ name, icon }: { name: string; icon: string }) {
  const [quote, setQuote] = useState("")
  const { handleSubmit } = useChat({
    api: "/api/generate-quote",
    onFinish: (message) => setQuote(message.content),
  })

  const generateQuote = () => {
    handleSubmit({ prompt: `Generate a short motivational quote about ${name}` })
  }

  return (
    <motion.div className="flex flex-col items-center" whileHover={{ scale: 1.1 }} onHoverStart={generateQuote}>
      <div className="hexagon bg-gradient-to-br from-blue-500 to-purple-500 w-24 h-24 flex items-center justify-center text-4xl">
        {icon}
      </div>
      <p className="mt-4 text-center font-semibold">{name}</p>
      {quote && (
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-2 text-sm text-center text-gray-400"
        >
          "{quote}"
        </motion.p>
      )}
    </motion.div>
  )
}

