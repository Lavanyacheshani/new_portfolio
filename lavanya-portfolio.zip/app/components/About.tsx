"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import { useChat } from "ai/react"

export default function About() {
  const [showChat, setShowChat] = useState(false)
  const { messages, input, handleInputChange, handleSubmit } = useChat()

  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl font-bold mb-12 text-center"
        >
          About Me
        </motion.h2>
        <div className="flex flex-col lg:flex-row items-center justify-between">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="lg:w-1/2 mb-8 lg:mb-0"
          >
            <h3 className="text-2xl font-semibold mb-4">Hi, I'm Lavanya Cheshani</h3>
            <p className="text-gray-300 mb-4">
              I'm a passionate software engineer and AI enthusiast with a knack for creating innovative solutions. With
              expertise in project management, UI/UX design, web development, and AI/ML, I strive to bridge the gap
              between cutting-edge technology and practical applications.
            </p>
            <p className="text-gray-300">
              My journey in tech has been driven by curiosity and a desire to make a positive impact. I'm always excited
              to take on new challenges and collaborate on projects that push the boundaries of what's possible.
            </p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="lg:w-1/2"
          >
            <h3 className="text-2xl font-semibold mb-4">Ask Me Anything</h3>
            <div className="bg-gray-800 p-4 rounded-lg shadow-lg">
              <div className="mb-4 h-40 overflow-y-auto">
                {messages.map((message, index) => (
                  <div key={index} className={`mb-2 ${message.role === "user" ? "text-blue-400" : "text-green-400"}`}>
                    <strong>{message.role === "user" ? "You: " : "Lavanya: "}</strong>
                    {message.content}
                  </div>
                ))}
              </div>
              <form onSubmit={handleSubmit} className="flex">
                <input
                  type="text"
                  value={input}
                  onChange={handleInputChange}
                  placeholder="Ask me about my skills, projects, or services..."
                  className="flex-grow px-4 py-2 bg-gray-700 text-white rounded-l-lg focus:outline-none"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700 transition-colors duration-300"
                >
                  Send
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

