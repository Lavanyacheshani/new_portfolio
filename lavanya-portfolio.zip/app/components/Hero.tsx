"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { useState, useEffect } from "react"
import { useChat } from "ai/react"

const taglines = [
  "Transforming ideas into AI-powered realities",
  "Bridging the gap between humans and AI",
  "Innovating at the intersection of AI and software engineering",
  "Crafting intelligent solutions for tomorrow's challenges",
]

export default function Hero() {
  const [currentTagline, setCurrentTagline] = useState(0)
  const { messages, input, handleInputChange, handleSubmit } = useChat()

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTagline((prev) => (prev + 1) % taglines.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <section className="min-h-screen flex flex-col justify-center items-center relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900 to-purple-900 opacity-50"></div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="z-10 text-center"
      >
        <Image
          src="/lavanya-photo.jpg"
          alt="Lavanya Cheshani"
          width={200}
          height={200}
          className="rounded-full border-4 border-blue-500 shadow-lg mb-8 hover:scale-105 transition-transform duration-300"
        />
        <h1 className="text-4xl md:text-6xl font-bold mb-4">Lavanya Cheshani</h1>
        <p className="text-xl md:text-2xl mb-8">AI Enthusiast | Software Engineer | Innovator</p>
        <motion.p
          key={currentTagline}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5 }}
          className="text-lg md:text-xl mb-12 h-8"
        >
          {taglines[currentTagline]}
        </motion.p>
        <div className="flex space-x-4 justify-center">
          <motion.a
            href="#projects"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full transition-colors duration-300"
          >
            View My Work
          </motion.a>
          <motion.a
            href="/resume.pdf"
            download
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-full transition-colors duration-300"
          >
            Download Resume
          </motion.a>
        </div>
      </motion.div>
    </section>
  )
}

