import Hero from "../components/skills/Hero"
import TechnicalSkills from "../components/skills/TechnicalSkills"
import SoftSkills from "../components/skills/SoftSkills"
import Experience from "../components/skills/Experience"
import Certifications from "../components/skills/Certifications"

export default function SkillsAndExperience() {
  return (
    <main className="min-h-screen bg-gray-900">
      <Hero />
      <TechnicalSkills />
      <SoftSkills />
      <Experience />
      <Certifications />
    </main>
  )
}

